# An Example Challenge

This challenge walks a learner through a few simple Linux challenges.

## About Challenges

This is an example [challenge](https://www.katacoda.community/challenges/challenges.html) that shows to integrate the _solver_ tool. The _solver_ tool helps authors create high-quality challenges.

The usage of _solver_ for O'Reilly challenge authors is detailed in the [Katacoda Documentation](https://www.katacoda.community/challenges/challenges-solver.html).

## About This Challenge

This is an example challenge that helps authors see how to create a complete challenge that utilizes the _solver_ tool. This can be used as a skeleton archetype to create your own challenge.

(If you are adopting this challenge as a canonical example, then add information here in this README about your challenge.)
