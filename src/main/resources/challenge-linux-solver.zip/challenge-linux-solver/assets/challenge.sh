#!/bin/bash

kc_start_tasks()
{
  kc_task \

  kc_task \

  kc_task \
}
