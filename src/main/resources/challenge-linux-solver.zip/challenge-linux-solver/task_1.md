<img align="right" src="./assets/cow-311266_640.png" width="15%">
Use `cowsay` with the quote:

`O'Reilly, inspiring the future for more than 40 years`

Steer this bovonic output to a file named `cowsay.txt`.
